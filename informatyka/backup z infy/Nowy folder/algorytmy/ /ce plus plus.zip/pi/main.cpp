#include <iostream>

using namespace std;

int main()
{
    const double pi = 22.0 / 7;
    cout << "wartosc stalej Pi wynosi: " << pi << endl;


    return 0;
}
