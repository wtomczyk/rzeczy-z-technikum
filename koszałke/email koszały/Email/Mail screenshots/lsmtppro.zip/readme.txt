Contents
--------

  Program information
  Author information
  Description
  Registration
  Technical support



Program information
-------------------

Program Archive Name:
  lsmtppro.zip
Program Name/Title:
  Local SMTP Server Pro
Program Version:
  5.26.0.93
Program Release Date:
  September 7, 2012
Program Description:
  SMTP server program that can be used as a local SMTP server or as a corporate
  high-performance SMTP server. The program has security and anti-spam features.
Target OS:
  All Windows
Software type:
  Shareware
  http://www.pc-safety.com/lsmtppropurchase.html
Program home page:
  http://www.pc-safety.com/lsmtppro.html



Author information
-------------------

Copyright:
  F-Key Solutions, Inc.
Contact WWW URL:
  http://www.pc-safety.com/contact.html
Our main Web Site
  http://www.pc-safety.com



Description                        
-----------

Local SMTP Server Pro is a SMTP server program that can be used as a local SMTP server or
as a corporate high-performance SMTP server. It can be used along with virtually
any mailer or email program including Microsoft Outlook, Outlook Express, Eudora,
Netscape and The Bat, and it is ideal for laptop PC users who travel a lot and
have to use different Internet Service Providers (ISP) on the run. You can use
it instead of your ISP's SMTP server to increase your email security and privacy
due to your email messages will be delivered directly to the mailboxes of your
recipients. The email program you already use for sending and receiving messages
can be connected to the server in a very easy way - just by using the word
"localhost" instead of your current SMTP host. Having done so, you can send
messages in a usual manner. Local SMTP Server Pro is very fast and reliable, it has a
flexible protection that lets you protect the server from the outside of the
Internet, and lets you block SPAM and spammers safely. The user interface of
the program is very easy to learn, excellent documentation is included. 



Registration
------------

This software is distributed as shareware. To keep the program on your
personal computer you should register it. The first step is to obtain a
registration code by paying a fee to us in the amount of $69 or with
some discounts depending on quantity of licenses(see below). You will find
all necessary information regarding registration on Order Form(see below).
The second step is to enter your registration code in the program.
Use Buy Program item of the tray menu to enter the code in the program.
To avoid errors, It is recommended to use Windows Clipboard while entering
the code.

Order Form:
  http://www.pc-safety.com/lsmtppropurchase.html

Discounts:
  Please, open the Order Form in your web browser to see information about
  the discounts we offer to our customers. Use the link above.


Technical support
-----------------

If you have a problem, please, contact us using this URL:
http://www.pc-safety.com/contact.html
(We answer our e-mail within 12-24 hours)
Please, inform us about the following:
 - Windows version (including service packs and other fixes installed);
 - detailed description of your problem.
If the problem is a bug in our program, it will be fixed in the next
version within a month.
If you have any comments or suggestions for the next releases, please
post them to us.
